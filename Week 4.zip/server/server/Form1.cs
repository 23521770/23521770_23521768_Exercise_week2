﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Windows.Forms;

namespace server
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        UdpClient server;
        IPEndPoint remoteIP;
        int remotPort = 55555;
        int port = 44444;

        private void button1_Click(object sender, EventArgs e)
        {
             server = new UdpClient(port);
                remoteIP = new IPEndPoint(IPAddress.Parse(textBox1.Text), remotPort);
                server.BeginReceive(new AsyncCallback(onReceive), server);
               
        }
        private void onReceive(IAsyncResult ar)
        {
            byte[] buff = server.EndReceive(ar, ref remoteIP);
            server.BeginReceive(new AsyncCallback(onReceive), server);
            ControlInvoke(richTextBox1, () => richTextBox1.AppendText(":>> " + Encoding.ASCII.GetString(buff)
                + Environment.NewLine));
        }
        private void button2_Click(object sender, EventArgs e)
        {
            
                    server.Connect(remoteIP);
                    server.Send(Encoding.ASCII.GetBytes(textBox2.Text),textBox2.Text.Length);
                     textBox2.Clear();
        }

        
        delegate void UniversalVoidDelegate();
        public static void ControlInvoke(Control control, Action function)
        {
           if (control.IsDisposed||control.Disposing) return;
           if (control.InvokeRequired)
            {
                control.Invoke(new UniversalVoidDelegate(()=>ControlInvoke(control,function)));return;

            }
            function();
        }
    }
}
