﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Windows.Forms;

namespace client
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        UdpClient client;
        IPEndPoint remoteIP;
        int port = 55555;
        int remotPort = 44444;

        private void button1_Click(object sender, EventArgs e)
        {
               client = new UdpClient(port);
                remoteIP = new IPEndPoint(IPAddress.Parse(textBox1.Text), remotPort);
                client.BeginReceive(new AsyncCallback(onReceive), client);
            
        }
        
        private void onReceive(IAsyncResult ar)
        {
            byte[] buff = client.EndReceive(ar, ref remoteIP);
                
                client.BeginReceive(new AsyncCallback(onReceive), client);

                // Update the UI with the received data
                ControlInvoke(richTextBox1, () => richTextBox1.AppendText(":>> " +Encoding.ASCII.GetString(buff)
                    +Environment.NewLine));
            
        }

        delegate void UniversalVoidDelegate();
        public static void ControlInvoke(Control control, Action function)
        {
            if (control.IsDisposed || control.Disposing) return;
            if (control.InvokeRequired)
            {
                control.Invoke(new UniversalVoidDelegate(() => ControlInvoke(control, function))); return;

            }
            function();
        }

        private void button2_Click(object sender, EventArgs e)
        {
           
                    client.Connect(remoteIP);
                    
                    client.Send(Encoding.ASCII.GetBytes(textBox2.Text),textBox2.Text.Length);
                    textBox2.Clear();
                
        }
    }
}
